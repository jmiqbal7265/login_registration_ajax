<?php

	session_start();

	include_once 'class.user.php';
	$user = new User();

	// Checking for user logged in or not

	if(isset($_REQUEST['register'])){
		extract($_REQUEST);

		$register = $user->reg_user($fullname, $uname, $upass, $uemail);

		if ($register) {
			// Registration Success
			$_SESSION['msg'] = '<div class="alert alert-success alert-dismissable">
	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	<strong>Success</strong>! Registration successful. <a href="login.php">Click here</a> to login.
	</div>';
			header("location: ../registration.php");
			exit();
		}else{
			// Registration Failed
			$_SESSION['msg'] = '<div class="alert alert-success alert-dismissable">
	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	<strong>Registration Failed</strong>! Email or username already exist.
	</div>';

			header("location: ../registration.php");
			exit();
		}
	}




?>